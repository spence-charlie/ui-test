// server/index.ts
import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

// Mount route modules
//import jwtRoutes from "./routes/jwt";
//import serversRoutes from "./routes/servers";
//app.use("/api/jwt", jwtRoutes);
//app.use("/api/servers", serversRoutes);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Express running on http://localhost:${PORT}`));
