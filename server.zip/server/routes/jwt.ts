// server/routes/jwt.ts
import { Router } from "express";
import * as jose from "jose";

const router = Router();

// Demo-only: do not use static secrets in production!
const HS256_SECRET = new TextEncoder().encode("dev-secret");

router.post("/encode", async (req, res) => {
  try {
    const token = await new jose.SignJWT(req.body.payload || {})
      .setProtectedHeader({ alg: "HS256" })
      .setIssuedAt()
      .setExpirationTime("1h")
      .sign(HS256_SECRET);
    res.json({ token });
  } catch (e: any) {
    res.status(400).json({ error: e.message });
  }
});

router.post("/decode", async (req, res) => {
  try {
    const { payload } = await jose.jwtVerify(req.body.token, HS256_SECRET, { algorithms: ["HS256"] });
    res.json({ payload });
  } catch (e: any) {
    res.status(400).json({ error: e.message });
  }
});

export default router;
