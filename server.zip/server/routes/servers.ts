// server/routes/servers.ts
import { Router } from "express";
const router = Router();

router.get("/", (_req, res) => {
  res.json([
    { id: "srv-1", name: "api-core", status: "healthy", cpu: 24, mem: 52 },
    { id: "srv-2", name: "worker", status: "degraded", cpu: 71, mem: 68 },
  ]);
});

export default router;
