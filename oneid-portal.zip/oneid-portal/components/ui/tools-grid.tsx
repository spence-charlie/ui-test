// app/(marketing)/_components/tools-grid.tsx
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { externalTools } from "@/data/external-tools";

type EnvMap = {
  NEXT_PUBLIC_GRAFANA_URL?: string;
  NEXT_PUBLIC_PROMETHEUS_URL?: string;
  NEXT_PUBLIC_KIBANA_URL?: string;
};

export async function ToolsGrid() {
  const envs: EnvMap = {
    NEXT_PUBLIC_GRAFANA_URL: process.env.NEXT_PUBLIC_GRAFANA_URL,
    NEXT_PUBLIC_PROMETHEUS_URL: process.env.NEXT_PUBLIC_PROMETHEUS_URL,
    NEXT_PUBLIC_KIBANA_URL: process.env.NEXT_PUBLIC_KIBANA_URL,
  };

  return (
    <section className="mx-auto max-w-6xl px-6 py-10">
      <h2 className="mb-4 text-xl font-semibold">External Tools</h2>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {externalTools.map((t) => {
          const href = envs[t.env] ?? "#";
          return (
            <Card key={t.name} className="transition-shadow hover:shadow-lg">
              <CardHeader>
                <CardTitle>{t.name}</CardTitle>
                <CardDescription>{t.desc}</CardDescription>
              </CardHeader>
              <CardContent>
                <a className="text-primary hover:underline" href={href} target="_blank" rel="noreferrer">
                  Open
                </a>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </section>
  );
}
