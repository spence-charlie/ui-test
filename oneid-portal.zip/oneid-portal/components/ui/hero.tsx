// app/(marketing)/_components/hero.tsx
"use client";

import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ReactTyped } from "react-typed";

export function Hero() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-20 text-center">
      <motion.h1
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-4xl font-bold tracking-tight sm:text-6xl"
      >
        {/* Static gradient on the brand text */}
        <span className="inline-block bg-gradient-to-r from-fuchsia-500 via-violet-500 to-cyan-400 bg-clip-text text-transparent">
          OneIdentityPortal
        </span>{" "}
        {/* Static gradient on the typewriter text (change colors as desired) */}
        <span className="inline-block bg-gradient-to-r from-indigo-500 via-sky-500 to-emerald-500 bg-clip-text text-transparent">
          <ReactTyped
            strings={["One Stop Shop..."]}
            typeSpeed={50}
            backSpeed={30}
            backDelay={1200}
            smartBackspace
            loop
            showCursor
            cursorChar="|"
          />
        </span>

        {/* Animated gradient variant (uncomment after enabling config below)
        <span className="inline-block bg-gradient-to-r from-indigo-500 via-sky-500 to-emerald-500 bg-clip-text text-transparent bg-[length:300%_100%] animate-gradient">
          <ReactTyped
            strings={["One Stop Shop..."]}
            typeSpeed={50}
            backSpeed={30}
            backDelay={1200}
            smartBackspace
            loop
            showCursor
            cursorChar="|"
          />
        </span>
        */}
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.12, duration: 0.6 }}
        className="mx-auto mt-4 max-w-2xl text-muted-foreground"
      >
        Utilities, links, search, and professional UI patterns — ready to extend.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.6 }}
        className="mt-8 flex items-center justify-center gap-3"
      >
        <Button asChild><a href="/tools/jwt">Open JWT Utility</a></Button>
        <Button variant="secondary" asChild><a href="/tools/servers">View Servers</a></Button>
      </motion.div>
    </section>
  );
}
