// app/(marketing)/_components/utilities-grid.tsx
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

const utilities = [
  { name: "JWT Utility", desc: "Encode/Decode demo with JOSE", href: "/tools/jwt" },
  { name: "Servers", desc: "Fetch/visualize server data", href: "/tools/servers" },
];

export function UtilitiesGrid() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-10">
      <h2 className="mb-4 text-xl font-semibold">Project Utilities</h2>
      <div className="grid gap-4 sm:grid-cols-2">
        {utilities.map((u) => (
          <Card key={u.name} className="transition-shadow hover:shadow-lg">
            <CardHeader>
              <CardTitle>{u.name}</CardTitle>
              <CardDescription>{u.desc}</CardDescription>
            </CardHeader>
            <CardContent>
              <a className="text-primary hover:underline" href={u.href}>
                Open
              </a>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}
