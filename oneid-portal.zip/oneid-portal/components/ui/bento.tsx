// app/(marketing)/_components/bento.tsx
"use client";

import { motion } from "framer-motion";

const items = [
  { title: "Keyboard-first", desc: "Global ⌘K palette", accent: "from-indigo-500 to-blue-500" },
  { title: "Scalable", desc: "Feature-first folders", accent: "from-emerald-500 to-teal-500" },
  { title: "Express API", desc: "Proxy via rewrites", accent: "from-rose-500 to-pink-500" },
  { title: "Modern UI", desc: "shadcn components", accent: "from-amber-500 to-orange-500" },
];

export function Bento() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-10">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {items.map((item) => (
          <motion.div
            key={item.title}
            whileHover={{ y: -2, scale: 1.01 }}
            className={`rounded-lg border bg-gradient-to-br ${item.accent} p-[1px]`}
          >
            <div className="rounded-lg bg-background p-4">
              <h3 className="font-semibold">{item.title}</h3>
              <p className="text-sm text-muted-foreground">{item.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
