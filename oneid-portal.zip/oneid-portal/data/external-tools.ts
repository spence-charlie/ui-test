// app/_data/external-tools.ts
export type ToolLink = {
  name: string;
  desc: string;
  env: "NEXT_PUBLIC_GRAFANA_URL" | "NEXT_PUBLIC_PROMETHEUS_URL" | "NEXT_PUBLIC_KIBANA_URL";
};

export const externalTools: ToolLink[] = [
  { name: "Grafana", desc: "Dashboards & alerts", env: "NEXT_PUBLIC_GRAFANA_URL" },
  { name: "Prometheus", desc: "Metrics & scraping", env: "NEXT_PUBLIC_PROMETHEUS_URL" },
  { name: "Kibana", desc: "Logs & search", env: "NEXT_PUBLIC_KIBANA_URL" },
];
