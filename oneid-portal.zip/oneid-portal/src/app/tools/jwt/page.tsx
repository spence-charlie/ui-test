// app/(tools)/jwt/page.tsx
"use client";
import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function JwtToolPage() {
  const [payload, setPayload] = useState('{"sub":"123","name":"Alice"}');
  const [token, setToken] = useState("");
  const [decoded, setDecoded] = useState("");

  const encode = async () => {
    const res = await fetch("/backend/api/jwt/encode", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ payload: JSON.parse(payload) }),
    });
    const data = await res.json();
    setToken(data.token || "");
  };

  const decode = async () => {
    const res = await fetch("/backend/api/jwt/decode", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token }),
    });
    const data = await res.json();
    setDecoded(JSON.stringify(data.payload || data, null, 2));
  };

  return (
    <main className="px-6 py-8">
      <Card>
        <CardHeader><CardTitle>JWT Encoder / Decoder</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm">Payload (JSON)</label>
            <Input value={payload} onChange={(e) => setPayload(e.target.value)} />
          </div>
          <Button onClick={encode}>Encode</Button>

          <div>
            <label className="text-sm">Token</label>
            <Input value={token} onChange={(e) => setToken(e.target.value)} />
          </div>
          <Button variant="secondary" onClick={decode}>Decode</Button>

          <pre className="bg-muted p-3 rounded text-sm overflow-auto">{decoded}</pre>
        </CardContent>
      </Card>
    </main>
  );
}
