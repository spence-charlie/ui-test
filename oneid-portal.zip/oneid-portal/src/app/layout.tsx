// app/layout.tsx
import "./globals.css";
import { CommandMenu } from "@/components/ui/command-menu";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <CommandMenu />
        {children}
      </body>
    </html>
  );
}
