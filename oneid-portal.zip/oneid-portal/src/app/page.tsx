// app/(marketing)/page.tsx
import { Hero } from "@/components/ui/hero";
import { ToolsGrid } from "@/components/ui/tools-grid";
import { UtilitiesGrid } from "@/components/ui/utilities-grid";
import { Bento } from "@/components/ui/bento";

export default function LandingPage() {
  return (
    <main>
      <Hero />
      <ToolsGrid />
      <UtilitiesGrid />
      <Bento />
    </main>
  );
}
