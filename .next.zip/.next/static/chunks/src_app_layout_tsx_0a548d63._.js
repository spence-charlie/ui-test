(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_globals_91e4631d.css",
  "static/chunks/node_modules_3f8b0069._.js",
  "static/chunks/_c3408f52._.js"
],
    source: "dynamic"
});
